package ru.myitschool.work.ui.login

import kotlinx.serialization.Serializable

@Serializable
data object LoginDestination